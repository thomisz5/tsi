//thomas sá capucho a2256576
public class Principal {
    private Principal() {}

    public static void main(String[] args) {
        InterfaceTexto it = new InterfaceTexto();
        it.renderizar();
    }
}